import './App.css';
import LogIn from './pages/LogIn';

function App() {
  return (
    <div className="App">
      <LogIn/>
    </div>
  );
}

export default App;
